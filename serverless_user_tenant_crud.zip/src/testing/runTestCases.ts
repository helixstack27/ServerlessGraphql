import { testMutation, testQuery } from "./testing";
testQuery
testMutation